import React, { useMemo, useState } from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";

import { useAppTheme } from "@/hooks/useAppTheme";
import PortfolioHoverChart, {
  type PortfolioPoint,
  type HoverPoint,
} from "@/components/PortfolioHoverChart";

import { TwitchCreatorsCard } from "@/components/TwitchCreatorsCard";
import UpcomingEventsBanner from "@/components/UpcomingEventsBanner";

type RangeKey = "1D" | "7D" | "30D" | "ALL";
type RangeDef = { key: RangeKey; label: string; days: number | "all" };

const RANGES: RangeDef[] = [
  { key: "1D", label: "1D", days: 1 },
  { key: "7D", label: "7D", days: 7 },
  { key: "30D", label: "30D", days: 30 },
  { key: "ALL", label: "ALL", days: "all" },
];

function generateDemoSeries(days: number | "all"): PortfolioPoint[] {
  const now = Date.now();
  const spanDays = days === "all" ? 365 : days;
  const totalPoints = Math.max(spanDays * 4, 40);

  const points: PortfolioPoint[] = [];
  let current = 20000;

  for (let i = totalPoints - 1; i >= 0; i--) {
    const t = now - ((spanDays * 24 * 60 * 60 * 1000) / totalPoints) * i;
    const delta = (Math.random() - 0.5) * (spanDays > 30 ? 600 : spanDays > 7 ? 400 : 250);
    current = Math.max(5000, current + delta);
    points.push({ t, value: current });
  }

  return points;
}

function formatCurrency(value: number | null | undefined): string {
  if (value == null || !Number.isFinite(value)) return "—";
  try {
    return new Intl.NumberFormat("de-DE", {
      style: "currency",
      currency: "EUR",
      maximumFractionDigits: 0,
    }).format(value);
  } catch {
    return `${value.toFixed(0)} EUR`;
  }
}

function formatShortDate(ts: number): string {
  const d = new Date(ts);
  if (Number.isNaN(d.getTime())) return "";
  try {
    return new Intl.DateTimeFormat("de-DE", { day: "2-digit", month: "2-digit" }).format(d);
  } catch {
    return d.toISOString().slice(5, 10);
  }
}

export default function PortfolioTab() {
  const t = useAppTheme();
  const colors: any = (t as any)?.colors ?? {};
  const spacing: any = (t as any)?.spacing ?? { xs: 6, sm: 10, md: 14, lg: 18, xl: 24 };
  const radius: any = (t as any)?.radius ?? { lg: 14 };

  const bg = colors.tiffany ?? colors.background ?? "#e7fbff";
  const card = colors.card ?? "#ffffff";
  const text = colors.navy ?? colors.text ?? "#0b1f3a";
  const muted = colors.mutedText ?? "#5b6b7a";
  const primary = colors.primary ?? "#19c2d0";
  const onPrimary = colors.onPrimary ?? "#ffffff";
  const surface = colors.surface ?? "#f3fbfd";

  const [rangeKey, setRangeKey] = useState<RangeKey>("7D");
  const [hoverPoint, setHoverPoint] = useState<HoverPoint | null>(null);

  const rangeDef = useMemo(() => RANGES.find((r) => r.key === rangeKey) ?? RANGES[1], [rangeKey]);
  const points = useMemo(() => generateDemoSeries(rangeDef.days), [rangeDef]);

  const latestValue = points.length ? points[points.length - 1].value : 0;
  const displayValue = hoverPoint?.value ?? latestValue;

  const displayLabel = hoverPoint
    ? formatShortDate(hoverPoint.t)
    : rangeKey === "ALL"
    ? "Last 12 months"
    : `Last ${rangeDef.label}`;

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: bg }}
      contentInsetAdjustmentBehavior="automatic"
      contentContainerStyle={{
        paddingTop: spacing.lg,
        paddingHorizontal: spacing.lg,
        paddingBottom: spacing.xl * 2,
        gap: spacing.md,
      }}
    >
      {/* Top: Collection Value */}
      <View
        style={{
          borderRadius: radius.lg,
          backgroundColor: card,
          padding: spacing.md,
        }}
      >
        <Text style={{ fontSize: 12, fontWeight: "600", color: muted, textTransform: "uppercase", marginBottom: 2 }}>
          Collection value
        </Text>

        <Text style={{ fontSize: 28, fontWeight: "700", color: text }}>
          {formatCurrency(displayValue)}
        </Text>

        <Text style={{ fontSize: 12, color: muted, marginTop: 2 }}>
          {displayLabel}
        </Text>
      </View>

      {/* Chart card */}
      <View
        style={{
          borderRadius: radius.lg,
          backgroundColor: card,
          padding: spacing.md,
        }}
      >
        <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: spacing.sm }}>
          {RANGES.map((r) => {
            const active = r.key === rangeKey;
            return (
              <TouchableOpacity
                key={r.key}
                onPress={() => setRangeKey(r.key)}
                style={{
                  flex: 1,
                  marginHorizontal: r.key === "7D" || r.key === "30D" ? spacing.xs : 0,
                  paddingVertical: 6,
                  borderRadius: 999,
                  alignItems: "center",
                  backgroundColor: active ? primary : surface,
                }}
                activeOpacity={0.85}
              >
                <Text style={{ fontSize: 12, fontWeight: "600", color: active ? onPrimary : text }}>
                  {r.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        <PortfolioHoverChart points={points} onPointChange={setHoverPoint} />
      </View>

      {/* Events preview banner */}
      <UpcomingEventsBanner context="portfolio" />

      {/* Twitch creators card */}
      <TwitchCreatorsCard />
    </ScrollView>
  );
}
