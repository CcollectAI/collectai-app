export { default } from "../../src/app/(tabs)/portfolio";
